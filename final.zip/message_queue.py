"""
Message Queue Manager - Handles pending messages with text-media matching
Text waits for media (image/video/audio), media waits for text.
Both sides queue and pair up within timeout.
"""
import time
from collections import defaultdict
from typing import Optional, Dict
import threading


class MessageQueue:
    """Queue system to match text with media for each user"""
    
    def __init__(self, text_wait_timeout=30):
        """
        Args:
            text_wait_timeout: Seconds each side waits for the other (default: 30)
        """
        self.pending_media = defaultdict(list)
        self.pending_text = defaultdict(list)
        self.text_wait_timeout = text_wait_timeout
        self.lock = threading.Lock()
        self.processed_messages = {}

    def _get_message_hash(self, message_type: str, data: dict) -> str:
        if message_type == 'text':
            return f"text:{data.get('text', '')}"
        url = data.get('url', '')
        caption = data.get('text', '')
        return f"{message_type}:{url}:{caption}"

    def add_message(self, sender: str, message_type: str, data: dict, message_id: str = None) -> Optional[Dict]:
        with self.lock:
            current_time = time.time()
            if not isinstance(data, dict):
                data = {}
            data['timestamp'] = current_time
            data['sender'] = sender

            if message_id:
                dedup_key = f"{sender}:id:{message_id}"
            else:
                dedup_key = f"{sender}:{self._get_message_hash(message_type, data)}"

            if dedup_key in self.processed_messages:
                if current_time - self.processed_messages[dedup_key] < 3600:
                    print(f"⭕ Duplicate skipped for {sender} [{message_type}]")
                    return {'duplicate': True, 'sender': sender}

            self.processed_messages[dedup_key] = current_time

            if message_type in ['image', 'video', 'audio']:
                if self.pending_text[sender]:
                    text_data = self.pending_text[sender].pop(0)
                    print(f"✅ Media arrived, paired with waiting text for {sender}")
                    return {
                        'text': text_data.get('text'),
                        'media': data,
                        'sender': sender
                    }
                else:
                    self.pending_media[sender].append(data)
                    print(f"⏳ Media queued, waiting for text from {sender}")
                    return None

            elif message_type == 'text':
                if self.pending_media[sender]:
                    media_data = self.pending_media[sender].pop(0)
                    print(f"✅ Text arrived, paired with waiting media for {sender}")
                    return {
                        'text': data.get('text'),
                        'media': media_data,
                        'sender': sender
                    }
                else:
                    self.pending_text[sender].append(data)
                    print(f"⏳ Text queued, waiting for media from {sender}")
                    return None

            return None

    def get_expired_media(self) -> list:
        """
        Returns media that waited longer than timeout WITH a caption/text attached.
        Media with NO caption is discarded (skipped).
        """
        with self.lock:
            expired = []
            current_time = time.time()

            for sender, messages in list(self.pending_media.items()):
                for msg in messages[:]:
                    if current_time - msg['timestamp'] > self.text_wait_timeout:
                        if msg.get('text'):
                            expired.append({'sender': sender, 'media': msg})
                        else:
                            print(f"⏭️ Skipping media-only (no text/caption) for {sender}")
                        messages.remove(msg)

            return expired

    def get_expired_text(self) -> list:
        """
        Returns text messages that waited longer than timeout with no media arriving.
        These will be processed as text-only.
        """
        with self.lock:
            expired = []
            current_time = time.time()

            for sender, messages in list(self.pending_text.items()):
                for msg in messages[:]:
                    if current_time - msg['timestamp'] > self.text_wait_timeout:
                        print(f"⏰ Text timeout for {sender}, processing as text-only")
                        expired.append({'sender': sender, 'text_data': msg})
                        messages.remove(msg)

            return expired

    def clear_user_queue(self, sender: str):
        with self.lock:
            if sender in self.pending_media:
                del self.pending_media[sender]
            if sender in self.pending_text:
                del self.pending_text[sender]

    def get_queue_status(self) -> dict:
        with self.lock:
            return {
                'pending_media_count': sum(len(msgs) for msgs in self.pending_media.values()),
                'pending_text_count': sum(len(msgs) for msgs in self.pending_text.values()),
                'users_with_pending': len(self.pending_media) + len(self.pending_text)
            }

