"""
Video Builder - Assembles the final bulletin MP4 using ffmpeg
"""

import os
import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import List, Optional, Tuple

WIDTH       = 1920
HEIGHT      = 1080
FPS         = 25
VIDEO_CODEC = 'libx264'
AUDIO_CODEC = 'aac'
PRESET      = 'fast'
CRF         = 23

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

from PIL import Image, ImageDraw, ImageFont

_NOTO_CANDIDATES = [
    "/usr/share/fonts/truetype/noto/NotoSansTelugu-Bold.ttf",
    "/usr/share/fonts/truetype/noto/NotoSerifTelugu-Bold.ttf",
    "/usr/share/fonts/truetype/noto/NotoSansTelugu-Regular.ttf",
    "/usr/share/fonts/noto/NotoSansTelugu-Bold.ttf",
]

TELUGU_FONT = os.environ.get('TELUGU_FONT', '')
if not TELUGU_FONT or not os.path.exists(TELUGU_FONT):
    for _f in _NOTO_CANDIDATES:
        if os.path.exists(_f):
            TELUGU_FONT = _f
            print(f"✓ Noto Telugu font: {_f}")
            break
if not TELUGU_FONT or not os.path.exists(TELUGU_FONT):
    _local = os.path.join(os.path.dirname(__file__), 'Gidugu Regular.otf')
    if os.path.exists(_local):
        TELUGU_FONT = _local
        print(f"✓ Local font: {_local}")
if not TELUGU_FONT or not os.path.exists(TELUGU_FONT):
    for _f in [r'C:\Windows\Fonts\NirmalaB.ttf', r'C:\Windows\Fonts\gautamib.ttf']:
        if os.path.exists(_f):
            TELUGU_FONT = _f
            break
if not TELUGU_FONT or not os.path.exists(TELUGU_FONT):
    print("❌ No Telugu font found! Run: apt-get install fonts-noto")
    TELUGU_FONT = 'Arial'


def _run(cmd: List[str], desc: str = '') -> bool:
    """Run an ffmpeg command, print output on failure."""
    print(f"  🔧 {desc or ' '.join(cmd[:4])}")
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print(f"  ❌ ffmpeg error:\n{result.stderr.decode()[-800:]}")
        return False
    return True


def _audio_duration(audio_path: str) -> float:
    cmd = [
        'ffprobe', '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        audio_path
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        return float(result.stdout.decode().strip())
    except Exception:
        return 5.0


def _video_duration(video_path: str) -> float:
    cmd = [
        'ffprobe', '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        video_path
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        return float(result.stdout.decode().strip())
    except Exception:
        return 15.4


def calculate_script_budget(
    target_seconds: float,
    intro_path: str,
    headline_audio_paths: List[str],
    n_scripts: int,
    min_script_seconds: float = 10.0,
) -> Tuple[float, float, float]:
    intro_dur       = _video_duration(intro_path)
    headline_total  = sum(_audio_duration(p) for p in headline_audio_paths)
    remaining       = target_seconds - intro_dur - headline_total
    per_script_cap  = max(min_script_seconds, remaining / n_scripts) if n_scripts > 0 else min_script_seconds

    print(f"\n⏱️  DURATION BUDGET")
    print(f"   Target          : {target_seconds:.1f}s ({target_seconds/60:.1f} min)")
    print(f"   Intro           : {intro_dur:.1f}s")
    print(f"   Headlines total : {headline_total:.1f}s  ({len(headline_audio_paths)} items)")
    print(f"   Scripts budget  : {remaining:.1f}s  → {per_script_cap:.1f}s per item")
    print(f"   Estimated total : {intro_dur + headline_total + per_script_cap * n_scripts:.1f}s")

    return intro_dur, headline_total, per_script_cap


def build_intro_segment(intro_path: str, out_path: str) -> bool:
    return _run([
        'ffmpeg', '-y', '-i', intro_path,
        '-vf', f'scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=decrease,'
               f'pad={WIDTH}:{HEIGHT}:(ow-iw)/2:(oh-ih)/2:black,'
               f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS',
        '-af', 'asetpts=PTS-STARTPTS',
        '-r', str(FPS),
        '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
        '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
        '-video_track_timescale', '12800',
        out_path
    ], 'Building intro segment')

def _create_headline_overlay(headline_text: str, width: int, height: int,
                              font_path: str):
    """
    PIL se headline PNG banao with proper Telugu rendering.
    Returns temp PNG path or None.
    """
    try:
        font_size = 120
        font = None
        try:
            font = ImageFont.truetype(font_path, font_size)
        except Exception:
            for fb in _NOTO_CANDIDATES:
                if os.path.exists(fb):
                    font = ImageFont.truetype(fb, font_size)
                    break
        if font is None:
            font = ImageFont.load_default()

        # Split on newlines from GPT; auto-wrap long lines
        raw_lines = headline_text.strip().split('\n')
        lines = []
        for raw in raw_lines:
            raw = raw.strip()
            if not raw:
                continue
            if len(raw) > 25:
                words = raw.split()
                cur = ""
                for w in words:
                    if len(cur) + len(w) + 1 <= 25:
                        cur = (cur + " " + w).strip()
                    else:
                        if cur:
                            lines.append(cur)
                        cur = w
                if cur:
                    lines.append(cur)
            else:
                lines.append(raw)
        if not lines:
            lines = [headline_text.strip()]

        # Measure
        dummy = Image.new('RGBA', (10, 10))
        draw  = ImageDraw.Draw(dummy)
        line_dims = []
        for line in lines:
            bb = draw.textbbox((0, 0), line, font=font)
            line_dims.append((bb[2]-bb[0], bb[3]-bb[1]))

        line_spacing = 22
        text_h = sum(d[1] for d in line_dims) + line_spacing * (len(lines) - 1)
        text_w = max(d[0] for d in line_dims)

        pad_x = 60; pad_y = 30
        card_w = min(text_w + pad_x * 2, width - 80)
        card_h = text_h + pad_y * 2

        img  = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        card_x = (width - card_w) // 2
        card_y = 310

        # Draw lines
        y = card_y + (card_h // 2) - (text_h // 2)
        for i, (line, (lw, lh)) in enumerate(zip(lines, line_dims)):
            x = (WIDTH - lw) // 2
            # Outline
            for dx, dy in [(-3,-3),(3,-3),(-3,3),(3,3),(0,-3),(0,3),(-3,0),(3,0)]:
                draw.text((x+dx, y+dy), line, font=font, fill=(0, 0, 0, 220))
            # Text
            draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
            y += lh + line_spacing

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='_hl.png')
        tmp.close()
        img.save(tmp.name, 'PNG')
        return tmp.name

    except Exception as e:
        print(f"  ❌ PIL overlay error: {e}")
        import traceback; traceback.print_exc()
        return None


def build_headline_card(headline_text: str, audio_path: str, out_path: str,
                        template_path: str = None) -> bool:
    """PIL-based headline card — proper Telugu rendering, no drawtext."""
    duration     = _audio_duration(audio_path)
    has_template = bool(template_path and os.path.exists(template_path))

    overlay_png = _create_headline_overlay(headline_text, WIDTH, HEIGHT, TELUGU_FONT)

    out_flags = [
        '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
        '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
        '-video_track_timescale', '12800',
        '-t', str(duration),
        out_path
    ]

    try:
        if has_template:
            bg_inputs = ['-stream_loop', '-1', '-t', str(duration), '-i', template_path]
            bg_vf     = f'scale={WIDTH}:{HEIGHT},fps={FPS},format=yuva420p,setpts=PTS-STARTPTS'
        else:
            bg_inputs = ['-f', 'lavfi',
                         '-i', f'color=c=0x780000:s={WIDTH}x{HEIGHT}:r={FPS}:d={duration}']
            bg_vf     = f'fps={FPS},format=yuva420p,setpts=PTS-STARTPTS'

        if overlay_png and os.path.exists(overlay_png):
            cmd = [
                'ffmpeg', '-y',
                *bg_inputs,
                '-i', overlay_png,
                '-i', audio_path,
                '-filter_complex',
                f'[0:v]{bg_vf}[bg];'
                f'[bg][1:v]overlay=0:0,fps={FPS},format=yuv420p,setpts=PTS-STARTPTS[outv]',
                '-map', '[outv]', '-map', '2:a',
                '-af', 'asetpts=PTS-STARTPTS',
                *out_flags
            ]
        else:
            cmd = [
                'ffmpeg', '-y',
                *bg_inputs,
                '-i', audio_path,
                '-vf', f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS',
                '-af', 'asetpts=PTS-STARTPTS',
                '-map', '0:v', '-map', '1:a',
                *out_flags
            ]

        return _run(cmd, f'Headline card (PIL): {headline_text[:40]}')

    finally:
        if overlay_png and os.path.exists(overlay_png):
            try: os.unlink(overlay_png)
            except: pass

def build_news_segment(media_path: str, script_audio_path: str,
                       logo_path: str, out_path: str,
                       max_duration: Optional[float] = None) -> bool:
    raw_duration = _audio_duration(script_audio_path)

    if max_duration is not None and raw_duration > max_duration:
        print(f"    ✂️  Audio {raw_duration:.1f}s → capped at {max_duration:.1f}s")
        duration = max_duration
    else:
        duration = raw_duration

    ext      = Path(media_path).suffix.lower()
    is_image = ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']

    logo_ext      = Path(logo_path).suffix.lower() if logo_path else ''
    logo_is_video = logo_ext in ['.mov', '.mp4', '.webm', '.avi']
    has_logo      = bool(logo_path and os.path.exists(logo_path))

    scale_filter = (
        f'scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,'
        f'crop={WIDTH}:{HEIGHT}'
    )

    inputs      = []
    input_index = 0

    if is_image:
        inputs += ['-loop', '1', '-t', str(duration), '-i', media_path]
    else:
        inputs += ['-stream_loop', '-1', '-t', str(duration), '-i', media_path]
    media_index  = input_index
    input_index += 1

    logo_index = None
    if has_logo:
        if logo_is_video:
            inputs += ['-stream_loop', '-1', '-t', str(duration), '-i', logo_path]
        else:
            inputs += ['-i', logo_path]
        logo_index   = input_index
        input_index += 1

    inputs     += ['-i', script_audio_path]
    audio_index = input_index

    if has_logo:
        filter_complex = (
            f'[{media_index}:v]{scale_filter}[scaled];'
            f'[{logo_index}:v]scale=350:-1[logo];'
            f'[scaled][logo]overlay=x=W-overlay_w-20:y=20,'
            f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS[outv]'
        )
    else:
        filter_complex = (
            f'[{media_index}:v]{scale_filter},'
            f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS[outv]'
        )

    cmd = [
        'ffmpeg', '-y',
        *inputs,
        '-filter_complex', filter_complex,
        '-map', '[outv]',
        '-map', f'{audio_index}:a',
        '-af', 'asetpts=PTS-STARTPTS',
        '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
        '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
        '-video_track_timescale', '12800',
        '-t', str(duration),
        out_path
    ]
    return _run(cmd, f'Building news segment: {Path(media_path).name}  [{duration:.1f}s]')


def build_filler_segment(logo_path: str, duration: float, out_path: str) -> bool:
    if duration <= 0:
        return False

    logo_ext   = Path(logo_path).suffix.lower() if logo_path else ''
    is_image   = logo_ext in ['.png', '.jpg', '.jpeg', '.webp']
    has_logo   = bool(logo_path and os.path.exists(logo_path) and is_image)

    if has_logo:
        return _run([
            'ffmpeg', '-y',
            '-loop', '1', '-t', str(duration), '-i', logo_path,
            '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
            '-vf', f'scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=decrease,'
                   f'pad={WIDTH}:{HEIGHT}:(ow-iw)/2:(oh-ih)/2:black,'
                   f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS',
            '-af', 'asetpts=PTS-STARTPTS',
            '-map', '0:v', '-map', '1:a',
            '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
            '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
            '-video_track_timescale', '12800',
            '-t', str(duration),
            out_path
        ], f'Building filler segment (logo image) [{duration:.3f}s]')
    else:
        return _run([
            'ffmpeg', '-y',
            '-f', 'lavfi', '-i', f'color=c=black:s={WIDTH}x{HEIGHT}:r={FPS}',
            '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
            '-vf', f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS',
            '-af', 'asetpts=PTS-STARTPTS',
            '-map', '0:v', '-map', '1:a',
            '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
            '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
            '-video_track_timescale', '12800',
            '-t', str(duration),
            out_path
        ], f'Building filler segment (black screen) [{duration:.3f}s]')


def _concat_demuxer(segment_paths: List[str], out_path: str) -> bool:
    """
    Concat using demuxer + stream copy. Fast and gapless when all segments
    share identical codec/resolution/fps/samplerate and have PTS starting
    from 0 (guaranteed by setpts=PTS-STARTPTS in every build_* function).
    """
    valid_paths = [s for s in segment_paths if os.path.exists(s)]
    if not valid_paths:
        return False

    list_fd, list_path = tempfile.mkstemp(suffix='.txt')
    try:
        with os.fdopen(list_fd, 'w', encoding='utf-8') as f:
            for seg in valid_paths:
                abs_path = os.path.abspath(seg).replace('\\', '/')
                f.write(f"file '{abs_path}'\n")

        return _run([
            'ffmpeg', '-y',
            '-f', 'concat',
            '-safe', '0',
            '-i', list_path,
            '-c', 'copy',
            out_path
        ], f'Concat {len(valid_paths)} segments → {Path(out_path).name}')
    finally:
        if os.path.exists(list_path):
            os.unlink(list_path)


def concatenate_segments(segment_paths: List[str], out_path: str,
                         target_duration: float = 0,
                         chunk_size: int = 6) -> bool:
    """
    Chunked concat to avoid Windows ffmpeg file-handle / filter-pad limits.

    WHY chunked:
      The previous approach used ffmpeg's concat FILTER with all N inputs at
      once. On Windows with 14 segments this causes:
        "Could not open encoder before EOF / Invalid argument"
      because ffmpeg runs out of resources managing that many simultaneous
      filter pads and open file handles.

    HOW it works:
      1. Split segments into groups of `chunk_size` (default 6)
      2. Concat each group into a temp intermediate file (demuxer + copy,
         fast because all segments are pre-normalized to identical params
         with PTS reset to 0)
      3. Final concat merges the small number of intermediate files

    This is gapless because:
      - Every segment was built with setpts=PTS-STARTPTS → PTS starts at 0
      - Demuxer copy just appends bitstream; no PTS gaps when source is clean
    """
    valid_paths = [s for s in segment_paths if os.path.exists(s)]
    if not valid_paths:
        print("❌ No valid segment paths found")
        return False

    n = len(valid_paths)
    print(f"  🔗 Joining {n} segments in chunks of {chunk_size}...")

    # Small enough to concat directly
    if n <= chunk_size:
        success = _concat_demuxer(valid_paths, out_path)
        if success and target_duration > 0:
            tmp = out_path + '_trim.mp4'
            if _run(['ffmpeg', '-y', '-i', out_path, '-t', str(target_duration),
                     '-c', 'copy', tmp], f'Trimming to {target_duration:.1f}s'):
                if os.path.exists(tmp):
                    os.replace(tmp, out_path)
        return success

    # Split into chunks → concat each chunk → merge chunks
    chunks = [valid_paths[i:i+chunk_size] for i in range(0, n, chunk_size)]
    tmp_dir = tempfile.mkdtemp(prefix='bulletin_chunks_')
    chunk_files = []

    try:
        for idx, chunk in enumerate(chunks):
            chunk_out = os.path.join(tmp_dir, f'chunk_{idx:03d}.mp4')
            print(f"  📦 Chunk {idx+1}/{len(chunks)} ({len(chunk)} segments)...")
            if not _concat_demuxer(chunk, chunk_out):
                print(f"  ❌ Chunk {idx+1} failed")
                return False
            chunk_files.append(chunk_out)

        print(f"  🔗 Merging {len(chunk_files)} chunks into final output...")
        success = _concat_demuxer(chunk_files, out_path)

        if success and target_duration > 0:
            tmp = out_path + '_trim.mp4'
            if _run(['ffmpeg', '-y', '-i', out_path, '-t', str(target_duration),
                     '-c', 'copy', tmp], f'Trimming to {target_duration:.1f}s'):
                if os.path.exists(tmp):
                    os.replace(tmp, out_path)

        return success

    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def build_bulletin_video(bulletin_dir: str, logo_path: str,
                         intro_path: str) -> Optional[str]:
    print("\n" + "=" * 60)
    print("🎬 BUILDING BULLETIN VIDEO")
    print("=" * 60)

    manifest_path = os.path.join(bulletin_dir, 'bulletin_manifest.json')
    if not os.path.exists(manifest_path):
        print(f"❌ manifest not found: {manifest_path}")
        return None

    with open(manifest_path, 'r', encoding='utf-8') as f:
        manifest = json.load(f)

    items            = manifest.get('items', [])
    duration_min     = manifest.get('duration_minutes', 0)
    bulletin_name    = manifest.get('bulletin_name', 'bulletin')
    # filler_duration  = float(manifest.get('filler_duration', 0.0))

    if not items:
        print("❌ No items in manifest")
        return None

    print(f"📋 Bulletin : {bulletin_name}")
    print(f"⏱️  Target   : {duration_min} min | Items: {len(items)}")

    from config import INPUT_IMAGE_DIR, INPUT_VIDEO_DIR, PREFIX_IMAGE, PREFIX_VIDEO

    headlines_dir = os.path.join(bulletin_dir, 'headlines')
    scripts_dir   = os.path.join(bulletin_dir, 'scripts')
    # segments_dir  = os.path.join(bulletin_dir, 'segments')

    # if os.path.exists(segments_dir):
    #     shutil.rmtree(segments_dir)
    # os.makedirs(segments_dir)
    segments_dir = tempfile.mkdtemp(prefix=f"segments_{bulletin_name}_")

    if not os.path.exists(intro_path):
        print(f"❌ Intro video not found: {intro_path}")
        return None

    def find_input_media(counter: int, media_type: str) -> Optional[str]:
        type_map = {
            'image': (INPUT_IMAGE_DIR, PREFIX_IMAGE, ['.jpg', '.jpeg', '.png', '.webp', '.gif']),
            'video': (INPUT_VIDEO_DIR, PREFIX_VIDEO, ['.mp4', '.mov', '.avi', '.mkv', '.webm']),
        }
        if media_type not in type_map:
            return None
        directory, prefix, exts = type_map[media_type]
        for ext in exts:
            candidate = os.path.join(directory, f"{prefix}{counter}{ext}")
            if os.path.exists(candidate):
                return candidate
        return None

    valid_items = []
    for item in items:
        ha_p = os.path.join(headlines_dir, item.get('headline_audio', ''))
        sa_p = os.path.join(scripts_dir,   item.get('script_audio',   ''))
        if os.path.exists(ha_p) and os.path.exists(sa_p):
            valid_items.append((item, ha_p, sa_p))
        else:
            print(f"  ⚠️ Skipping item {item.get('rank')} — audio file(s) missing")

    if not valid_items:
        print("❌ No valid items with audio files")
        return None

    target_seconds  = duration_min * 60
    per_script_cap  = None
    all_segments: List[str] = []
    seg_idx = 0

    # ── [1/4] Intro ──────────────────────────────────────────────────────────
    print("\n[1/4] Building intro segment...")
    intro_seg = os.path.join(segments_dir, f'{str(seg_idx).zfill(3)}_intro.mp4')
    seg_idx  += 1
    if not build_intro_segment(intro_path, intro_seg):
        return None
    all_segments.append(intro_seg)

    # ── Template check ────────────────────────────────────────────────────────
    from config import BASE_DIR as _BASE_DIR
    template_path = os.path.join(_BASE_DIR, 'template.mp4')
    print(f"  📁 Template path: {template_path} | exists: {os.path.exists(template_path)}")
    if not os.path.exists(template_path):
        print(f"⚠️ template.mp4 not found — using black background")
        template_path = None

    # ── [2/4] Headlines ───────────────────────────────────────────────────────
    print(f"\n[2/4] Building headlines reel ({len(valid_items)} headlines)...")
    for item, ha_p, _ in valid_items:
        rank          = item['rank']
        headline_text = item.get('headline', '')
        card_path = os.path.join(segments_dir, f'{str(seg_idx).zfill(3)}_headline_{rank:02d}.mp4')
        seg_idx  += 1
        if build_headline_card(headline_text, ha_p, card_path, template_path):
            all_segments.append(card_path)
        else:
            print(f"  ⚠️ Skipping headline card {rank}")

    # ── [3/4] News segments ───────────────────────────────────────────────────
    cap_display = f"{per_script_cap:.1f}s" if per_script_cap is not None else "no cap"
    print(f"\n[3/4] Building {len(valid_items)} news segments (cap: {cap_display} each)...")
    for item, _, sa_p in valid_items:
        rank       = item['rank']
        counter    = item.get('counter')
        media_type = item.get('media_type', 'image')

        media_file = find_input_media(counter, media_type)
        if not media_file:
            print(f"  ⚠️ Input media not found for item {rank} (counter={counter}, type={media_type})")

        news_seg = os.path.join(segments_dir, f'{str(seg_idx).zfill(3)}_news_{rank:02d}.mp4')
        seg_idx += 1

        if media_file:
            allocated_dur = float(item.get('script_duration', 0.0)) or None
            success = build_news_segment(
                media_path        = media_file,
                script_audio_path = sa_p,
                logo_path         = logo_path,
                out_path          = news_seg,
                max_duration      = allocated_dur,
            )
        else:
            raw_dur  = _audio_duration(sa_p)
            duration = min(raw_dur, per_script_cap) if per_script_cap else raw_dur
            if per_script_cap and raw_dur > per_script_cap:
                print(f"    ✂️  Fallback audio {raw_dur:.1f}s → capped at {duration:.1f}s")
            success = _run([
                'ffmpeg', '-y',
                '-f', 'lavfi', '-i', f'color=c=black:s={WIDTH}x{HEIGHT}:r={FPS}:d={duration}',
                '-i', sa_p,
                '-vf', f'fps={FPS},format=yuv420p,setpts=PTS-STARTPTS',
                '-af', 'asetpts=PTS-STARTPTS',
                '-c:v', VIDEO_CODEC, '-preset', PRESET, '-crf', str(CRF),
                '-c:a', AUDIO_CODEC, '-ar', '44100', '-ac', '2',
                '-video_track_timescale', '12800',
                '-map', '0:v', '-map', '1:a',
                '-t', str(duration),
                news_seg
            ], f'Building black fallback segment for item {rank}  [{duration:.1f}s]')

        if success:
            all_segments.append(news_seg)
        else:
            print(f"  ⚠️ Skipping news segment {rank}")

    # ── [4/4] Filler ─────────────────────────────────────────────────────────
    # if filler_duration > 0.1:
    #     print(f"\n[4/4] Building filler segment ({filler_duration:.3f}s)...")

    # Dynamically calculate filler based on actual built segments
    actual_so_far = sum(_video_duration(seg) for seg in all_segments)
    IST_INTRO_DURATION = 2
    filler_duration = target_seconds - actual_so_far - IST_INTRO_DURATION
    print(f"\n[4/4] Building filler segment (dynamic: {target_seconds:.1f}s - {actual_so_far:.3f}s = {filler_duration:.3f}s)...")

    if filler_duration > 0.1:
        filler_seg = os.path.join(segments_dir, f'{str(seg_idx).zfill(3)}_filler.mp4')
        seg_idx   += 1
        filler_png = os.path.join(BASE_DIR, 'filler.jpeg')
        print(f"  📁 Filler path: {filler_png} | exists: {os.path.exists(filler_png)}")
        if build_filler_segment(filler_png, filler_duration, filler_seg):
            all_segments.append(filler_seg)
            print(f"  ✅ Filler added: {filler_duration:.3f}s")
        else:
            print(f"  ⚠️ Filler segment failed — video will be short by {filler_duration:.1f}s")
    else:
        print(f"\n[4/4] Filler skipped (gap={filler_duration:.3f}s < 0.1s)")

    if not all_segments:
        print("❌ No segments built")
        return None

    print(f"\n🔗 Concatenating {len(all_segments)} segments...")

    final_path     = os.path.join(bulletin_dir, f'{bulletin_name}.mp4')
    final_path_tmp = final_path + '_tmp.mp4'

    if not concatenate_segments(all_segments, final_path_tmp, target_duration=target_seconds):
        return None

    os.replace(final_path_tmp, final_path)

    actual_dur = _video_duration(final_path)
    size_mb    = os.path.getsize(final_path) / (1024 * 1024)

    print(f"\n✅ Bulletin video ready!")
    print(f"   📁 {final_path}")
    print(f"   📦 {size_mb:.1f} MB")
    print(f"   ⏱️  Actual duration : {actual_dur:.1f}s  ({actual_dur/60:.2f} min)")
    print(f"   🎯 Target duration  : {target_seconds:.1f}s  ({duration_min:.0f} min)")
    print(f"   📊 Difference       : {actual_dur - target_seconds:+.1f}s")
    print("=" * 60)

    manifest['final_video']       = final_path
    manifest['actual_duration_s'] = round(actual_dur, 2)
    manifest['target_duration_s'] = target_seconds
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    shutil.rmtree(segments_dir, ignore_errors=True)

    return final_path


def _latest_bulletin_dir():
    from config import BASE_OUTPUT_DIR
    bulletins_root = os.path.join(BASE_OUTPUT_DIR, 'bulletins')
    if not os.path.exists(bulletins_root):
        return None
    folders = [
        os.path.join(bulletins_root, d)
        for d in os.listdir(bulletins_root)
        if os.path.isdir(os.path.join(bulletins_root, d))
        and os.path.exists(os.path.join(bulletins_root, d, 'bulletin_manifest.json'))
    ]
    if not folders:
        return None
    return max(folders, key=os.path.getctime)


if __name__ == '__main__':
    import sys
    from config import BASE_DIR

    if len(sys.argv) >= 2:
        bulletin_dir = sys.argv[1]
    else:
        bulletin_dir = _latest_bulletin_dir()
        if not bulletin_dir:
            from bulletin_builder import build_bulletin
            print("No bulletin folder found — building 5-min bulletin first...")
            bulletin_dir = build_bulletin(5)
        if not bulletin_dir:
            print("Could not find or create a bulletin.")
            sys.exit(1)
        print(f"Using bulletin: {bulletin_dir}")

    logo  = sys.argv[2] if len(sys.argv) >= 3 else os.path.join(BASE_DIR, 'logo.mov')
    intro = sys.argv[3] if len(sys.argv) >= 4 else os.path.join(BASE_DIR, 'intro.mp4')

    result = build_bulletin_video(bulletin_dir, logo, intro)
    if result:
        print(f"Done: {result}")
    else:
        print("Video build failed")
        sys.exit(1)

